import array as arr
import numpy

def faulty_number_of_rows_column(matrix,row_or_column):
    faulty_rows=[0 for i in range(row_or_column)]
    for k in matrix:
        idx=-1
        for i in k:
            idx+=1
            for j in i:
                if(j == '0'):
                    faulty_rows[idx]+=1
                    break
    return faulty_rows


def faulty_brams_rows_w_count(matrix):
    faulty_rows=[[0 for j in range(16)] for i in range(1024)]
    for k in matrix:
        idx=-1
        for i in k:
            idx+=1
            error=0
            for j in i:
                if(j == '0'):
                    error+=1
            if(error > 0):
                faulty_rows[idx][error]+=1

    return faulty_rows

def faulty_brams_coarsed(matrix):
    faulty_rows=[[0 for j in range(16)] for i in range(number_of_bram)]
    error=0
    idx=-0
    for k in matrix:
        for i in k:
            error=0
            for j in i:
                if(j == '0'):
                    error+=1
            if(error > 0):
                faulty_rows[idx][error]+=1
        idx+=1

    return faulty_rows
