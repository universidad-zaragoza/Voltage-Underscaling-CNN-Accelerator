import argparse
import array as arr
import numpy as np
import per_bram



parser = argparse.ArgumentParser()
parser.add_argument("-s","--stage",required=True,
                    help='voltage-level s=0 for KC705 its 0.53 for VC707 its 0.54')
args = vars(parser.parse_args())

kc="{}".format(0.53+int(args['stage'])*0.01)
vc="{}".format(0.54+int(args['stage'])*0.01)

#print(args)
filename1 = "KC705B" + "-" + kc + ".bin"
filename2 = "VC707" + "-" + vc + ".bin"
pwd = "/home/ismail/FPGA-BRAMs-Undervoltig-Study/fault_characterization/"
path1 = pwd + "KC705B" + "/RawData/" + filename1
path2 = pwd + "VC707" + "/RawData/" + filename2
dir_name = "stats/"

path_row_percentage= pwd + dir_name+ "row_percentage_" +args['stage']
path_column_percentage = pwd + dir_name+"column_percentage_" + args['stage']
path_row_distance = pwd + dir_name+"row_distance_" + args['stage']
path_column_distance = pwd +dir_name + "column_distance_" + args['stage']
path_coarse_stats = pwd +dir_name + "coarse_stats_" + args['stage']

err=0
f1 = open(path1,"r")
f2 = open(path2,"r")

r_bit_faults = [0 for i in range(16)]
c_bit_faults = [0 for i in range(1024)]

m1 = per_bram.initiliaze_per_bram_matrix(f1,890)
m2 = per_bram.initiliaze_per_bram_matrix(f2,2060)
row_percentage = open(path_row_percentage,"w")
column_percentage = open(path_column_percentage,"w")
row_distance = open(path_row_distance,"w")
column_distance = open(path_column_distance,"w")
coarse_stats = open(path_coarse_stats,"w")
m = m1 + m2
np.save("whole_brams",m)
faulty_brams= [0 for i in range(2060+890)]
for i,a in enumerate(m):
    for b in a:
        if( sum(b) < 16 ):
            faulty_brams[i]+=1
            break
print(sum(faulty_brams))
f_brams = [[[0 for i in range(16)]for i in range(1024)]for i in range(sum(faulty_brams))]
for i,a in enumerate(faulty_brams):
    if(a > 0):
        f_brams[i] = m[a]
np.save("faulty_brams",f_brams)

"""

#ROW-BASED STATS
##Row-percentage
for a in m:
    for b in a:
        r_bit_faults[16-sum(b)]+=1
for i,b in enumerate(r_bit_faults):
    str = "{}\n".format(b*1.0/sum(r_bit_faults))
    row_percentage.write(str)

row_percentage.close()

##Row-distance
row_distances = [0 for i in range(16)]

for a in m:
    for b in a:
        idx=-1
        for i,c in enumerate(b):
            if(c == 0):
                err+=1
                if(idx != -1):
                    row_distances[i-idx]+=1
                idx = i
for i,x in enumerate(row_distances):
        str = "{}\n".format(x)
        row_distance.write(str)

row_distance.close()

#COLUMN-BASED STATS
##Column-Percentage

for a in m:
    t_m = np.transpose(a)
    for b in t_m:
        c_bit_faults[1024-sum(b)]+=1

for i,b in enumerate(c_bit_faults):
    str = "{}\n".format(b*1.0/sum(c_bit_faults))
    column_percentage.write(str)

column_percentage.close()


##Column-distance
column_distances = [0 for i in range(1024)]

for a in m:
    t_m = np.transpose(a)
    for b in t_m:
        idx=-1
        for i,c in enumerate(b):
            if(c == 0):
                err+=1
                if(idx != -1):
                    column_distances[i-idx]+=1
                idx = i
for i,x in enumerate(column_distances):
    str = "{}\n".format(x)
    column_distance.write(str)

column_distance.close()

err=0
for a in m:
    for b in a:
        for c in b:
            if(c == 0):
                err+=1
faulty_brams=0
for a in m:
    for b in a:
        if(sum(b) < 16):
            faulty_brams+=1
            break

str = "{}\n".format(err)
coarse_stats.write(str)
str = "{}\n".format(faulty_brams)
coarse_stats.write(str)

coarse_stats.close()
"""
