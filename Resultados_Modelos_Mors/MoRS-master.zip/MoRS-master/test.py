import argparse
import array as arr
import numpy as np
import per_bram



parser = argparse.ArgumentParser()
parser.add_argument("-b","--board",required=True,
                    help='Board Selection. available boards:KC705B or VC707')
parser.add_argument("-v","--voltage-level",required=True,
                    help='Voltage Level, for KC705B interval is 0.59-0.53, for VC707 is 0.60-0.54')

args = vars(parser.parse_args())

if(args['board'] == 'KC705B'):
    number_of_bram = 890
else:
    number_of_bram = 2060

#print(args)
filename = args['board'] + "-" + args['voltage_level'] + ".bin"
pwd = "/home/ismail/FPGA-BRAMs-Undervoltig-Study/fault_characterization/"
path = pwd + args['board'] + "/RawData/" + filename
dir_name = "stats/"
path_row_percentage= pwd + dir_name+ "row_percentage_" + args['board'] + "_" +args['voltage_level']
path_column_percentage = pwd + dir_name+"column_percentage_" + args['board'] + "_" +args['voltage_level']
path_row_distance = pwd + dir_name+"row_distance_" + args['board'] + "_" +args['voltage_level']
path_column_distance = pwd +dir_name + "column_distance_" + args['board'] + "_" +args['voltage_level']
path_coarse_stats = pwd +dir_name + "coarse_stats_" + args['board'] + "_" +args['voltage_level']
path_piece = pwd +dir_name +  args['board'] + "_pieces"
err=0
f = open(path,"r")
piece = 850
piece_brams = [0 for i in range(piece)]
numbers_of_pieces = [0 for i in range(piece)]

r_bit_faults = [0 for i in range(16)]
c_bit_faults = [0 for i in range(1024)]
m = per_bram.initiliaze_per_bram_matrix(f,number_of_bram)
row_percentage = open(path_row_percentage,"w")
column_percentage = open(path_column_percentage,"w")
row_distance = open(path_row_distance,"w")
column_distance = open(path_column_distance,"w")
coarse_stats = open(path_coarse_stats,"w")
"""
per_bram_fault = [0 for i in range(number_of_bram)]
numbers_of_piece = open(path_piece,"w")
for i,a in enumerate(m):
    for b in a:
        per_bram_fault[i] += 16-sum(b)

idx=0
pop=0
for i,a in enumerate(per_bram_fault):
    if(a > min(piece_brams)):
        if(idx > 849):
            for t,x in enumerate(piece_brams):
                if(x == min(piece_brams)):
                    pop=t
                    break
            piece_brams[pop]=a
            numbers_of_pieces[pop] = i
        else:
            piece_brams[idx] = a
            numbers_of_pieces[idx] = i
            idx+=1
for i in range(piece):
    print(numbers_of_pieces[i],piece_brams[i])

print(sum(per_bram_fault),sum(piece_brams))

numbers_of_pieces = sorted(numbers_of_pieces)
for i in numbers_of_pieces:
    str = "{}\n".format(i)
    numbers_of_piece.write(str)
numbers_of_piece.close()
"""


#ROW-BASED STATS
##Row-percentage
for a in m:
    for b in a:
        r_bit_faults[16-sum(b)]+=1
for i,b in enumerate(r_bit_faults):
    str = "{}\n".format(b*1.0/sum(r_bit_faults))
    row_percentage.write(str)

row_percentage.close()

##Row-distance
row_distances = [0 for i in range(16)]

for a in m:
    for b in a:
        idx=-1
        for i,c in enumerate(b):
            if(c == 0):
                err+=1
                if(idx != -1):
                    row_distances[i-idx]+=1
                idx = i
for i,x in enumerate(row_distances):
        str = "{}\n".format(x)
        row_distance.write(str)

row_distance.close()

#COLUMN-BASED STATS
##Column-Percentage

for a in m:
    t_m = np.transpose(a)
    for b in t_m:
        c_bit_faults[1024-sum(b)]+=1

for i,b in enumerate(c_bit_faults):
    str = "{}\n".format(b*1.0/sum(c_bit_faults))
    column_percentage.write(str)

column_percentage.close()


##Column-distance
column_distances = [0 for i in range(1024)]

for a in m:
    t_m = np.transpose(a)
    for b in t_m:
        idx=-1
        for i,c in enumerate(b):
            if(c == 0):
                err+=1
                if(idx != -1):
                    column_distances[i-idx]+=1
                idx = i
for i,x in enumerate(column_distances):
    str = "{}\n".format(x)
    column_distance.write(str)

column_distance.close()

err=0
for a in m:
    for b in a:
        for c in b:
            if(c == 0):
                err+=1
faulty_brams=0
for a in m:
    for b in a:
        if(sum(b) < 16):
            faulty_brams+=1
            break

str = "{}\n".format(err)
coarse_stats.write(str)
str = "{}\n".format(faulty_brams)
coarse_stats.write(str)

coarse_stats.close()
