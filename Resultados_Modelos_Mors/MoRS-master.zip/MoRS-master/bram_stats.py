import argparse
import array as arr
import numpy
from per_bram import *




parser = argparse.ArgumentParser()
parser.add_argument("-b","--board",required=True,
                    help='Board Selection. available boards:KC705B or VC707')
parser.add_argument("-v","--voltage-level",required=True,
                    help='Voltage Level, for KC705B interval is 0.59-0.53, for VC707 is 0.60-0.54')

args = vars(parser.parse_args())

if(args['board'] == 'KC705B'):
    number_of_bram = 890
else:
    number_of_bram = 2060

#print(args)
filename = args['board'] + "-" + args['voltage_level'] + ".bin"
pwd = "/home/ismail/FPGA-BRAMs-Undervoltig-Study/fault_characterization/"
path = pwd + args['board'] + "/RawData/" + filename
idx=0;


f = open(path,"r")

matrix = initiliaze_per_bram_matrix(f,number_of_bram)
t_matrix = numpy.moveaxis(matrix, 2, 1)

n_faulty_columns = faulty_number_of_rows_column(t_matrix,1024)
faulty_brams_column =  bram_based_faulty_number_of_rows_column(t_matrix,16)
column_distances = error_distance_in_rows(t_matrix,1024)

n_faulty_rows = faulty_number_of_rows_column(matrix,16)
faulty_brams_row =  bram_based_faulty_number_of_rows_column(matrix,1024)
row_distances = error_distance_in_rows(matrix,16)

total_error = error_count(matrix)

print(filename)
print("*************Coarse-grained statistics*************")
print('')
print("Number of faulty cells: {}".format(total_error))

error_percentage = (total_error/(number_of_bram*1024.0*16.0))*100.0;
print("Error percentage %{}" .format(error_percentage))
print('')
print("*************Fine-grained statistics*************")
print('')
print("-----Row-based statistics-----")
print("--Row_errors:")
tt=0
for x in n_faulty_rows:
    if(x > 0):
        print("{}-bit errors in rows: {}".format(tt,x))
    tt+=1

print("--Row_distances:")
tt=0
for x in row_distances:
    if(x > 0):
        print("{}-bitcell distance in rows: {}".format(tt,x))
    tt+=1

print('')
print("-----Column-based statistics-----")

print("--Column_errors:")
tt=0
for x in n_faulty_columns:
    if(x > 0):
        print("{}-bit errors in columns: {}".format(tt,x))
    tt+=1

print("--Column distances:")
tt=0
for x in column_distances:
    if(x > 0):
        print("{}-bitcell distance in columns: {}".format(tt,x))
    tt+=1

print('')
print("-----BRAM-based statistics-----")

print("--In terms of Row:")
tt=0
for x in faulty_brams_row:
    if(x > 0):
        print("{} faulty rows in number of brams: {}".format(tt,x))
    tt+=1

print("--In terms of Column:")
tt=0
for x in faulty_brams_column:
    if(x > 0):
        print("{} faulty column in number of brams: {}".format(tt,x))
    tt+=1
print("*****************************************************************")


"""
tt=-1
ta=0
check=0
_str=''
for x in faulty_rows_bit:
    tt+=1
    ta=0
    _str=''
    for y in x:
        if(y > 0):
            _str= str(_str) + str(" ") + str(ta) + str("-bits errors: ") + str(y) + str(", ")
            check=1
        ta+=1
    if(check == 1):
        print(tt,_str)
        check=0

"""
