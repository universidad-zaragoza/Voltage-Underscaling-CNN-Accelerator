import array as arr
import numpy
from very_detailed_stats import *

def initiliaze_per_bram_matrix(file,number_of_bram):
    matrix = [[[0 for j in range(16)] for i in range(1024)] for k in range(number_of_bram)]
    a=[0 for j in range(16)]
    idx=int(0)
    idxx=0
    a_i=0
    for x in file:
        for ch in x:
            bits = format(int(ch,16),"04b")
            for i in bits:
                a[a_i]=int(i)
                a_i+=1
            idxx+=1
            if(idxx == 4):
                matrix[int(idx/1024)][int(idx%1024)] = a
                a=[0 for j in range(16)]
                idx+=1
                idxx=0
                a_i=0

    return matrix

def faulty_number_of_rows_column(matrix,row_or_column):
    faulty_rows=[0 for i in range(row_or_column)]
    for k in matrix:
        idx=-1
        for i in k:
            idx+=1
            error=0
            for j in i:
                if(j == '0'):
                    error+=1

            if(error > 0):
                faulty_rows[error]+=1

    return faulty_rows

def bram_based_faulty_number_of_rows_column(matrix,row_or_column):
    faulty_brams = [0 for i in range(row_or_column)]
    err_c=0
    for k in matrix:
        for i in k:
            for j in i:
                if( j == '0'):
                    err_c+=1
                    break
        faulty_brams[err_c]+=1
        err_c=0
    return faulty_brams

def error_count(matrix):
    faulty_rows=faulty_brams_rows_w_count(matrix)
    error=0
    for i in faulty_rows:
        idx=0
        for j in i:
            error+= j*idx
            idx+=1
    return error

def error_distance_in_rows(matrix,row_or_column):
    distance=[0 for j in range(row_or_column)]
    for k in matrix:
        for x in k:
            idx=0
            first_occurance=0
            first=1
            for bit in x:
                if(bit == '0'):
                    if(first == 1):
                        first = 0
                    else:
                        distance[idx-first_occurance]+=1
                    first_occurance=idx
                idx+=1
    return distance
