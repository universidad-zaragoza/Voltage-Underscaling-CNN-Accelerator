import argparse
import array as arr
import numpy as np
from per_bram import *
from random import seed
from random import choice
import random
seed(random)
parser = argparse.ArgumentParser()
parser.add_argument("-b","--board",required=True,
                    help='Board Selection. available boards:KC705B or VC707')
parser.add_argument("-v","--voltage-level",required=True,
                    help='Voltage Level, for KC705B interval is 0.59-0.53, for VC707 is 0.60-0.54')
parser.add_argument("-m","--model",required=True,
                    help='Model selection,available versions: [0,3] \n0:total random \n1:row-based \n2:column-based \n3:mixed(row&column) ')
args = vars(parser.parse_args())
pwd = "/home/ismail/FPGA-BRAMs-Undervoltig-Study/fault_characterization/"

if(args['board'] == 'KC705B'):
    number_of_bram = 890
elif(args['board'] == 'VC707'):
    number_of_bram = 2060



dir_name = "stats/"
path_row_percentage= pwd + dir_name+ "row_percentage_" + args['board'] + "_" +args['voltage_level']
path_column_percentage = pwd + dir_name+"column_percentage_" + args['board'] + "_" +args['voltage_level']
path_row_distance = pwd + dir_name+"row_distance_" + args['board'] + "_" +args['voltage_level']
path_column_distance = pwd +dir_name + "column_distance_" + args['board'] + "_" +args['voltage_level']
path_coarse_stats = pwd +dir_name + "coarse_stats_" + args['board'] + "_" +args['voltage_level']
path_result = pwd + "result_" + args['board'] + "_" +args['voltage_level']

n_bram=850
pf = open(path_coarse_stats,"r")
tempf = [0 for i in range(2)]
for i,x in enumerate(pf):
    tempf[i] = int(x)
num_of_faulty_brams = int((tempf[1]/number_of_bram)*n_bram) + 1

fault = (n_bram-num_of_faulty_brams)

num_err = int((tempf[0]/number_of_bram)*n_bram) + 1

number_of_bram = n_bram

per_row_distances = [0 for i in range(16)]
per_column_distances = [0 for i in range(1024)]
per_row_stats = [0 for i in range(16)]
per_column_stats = [0 for i in range(1024)]


brams = [[[1 for j in range(16)] for i in range(1024)] for k in range(number_of_bram)]


if(args['model'] == '0'):


    sequence1 = [i for i in range(1024)]
    sequence2 = [i for i in range(16)]
    sequence3 = [i for i in range(number_of_bram)]
    for _ in range(num_err):
        row = choice(sequence1)
        cell =choice(sequence2)
        no = choice(sequence3)
        brams[no][row][cell] = 0

if(args['model'] == '1'):

    ff = open(path_row_percentage,"r")
    ar = [0 for i in range(16)]
    for i,x in enumerate(ff):
        ar[i] = float(x)
    min=1
    for w in ar:
        if(w > 0):
            if(w < min):
                min = w
    x = 1/min
    sequence3 = [0 for i in range(0)]
    for i,a in enumerate(ar):
        sequence3 += [i for t in range(int((x*a+0.001)))]

    sequence5 = [0 for i in range(num_of_faulty_brams)] + [1 for i in range(fault)]
    sequence1 = [i for i in range(1024)]
    sequence2 = [i for i in range(16)]

    random.shuffle(sequence3)
    random.shuffle(sequence5)

    while num_err > 0:
        for bram_no,is_faulty in enumerate(sequence5):
            if( is_faulty == 0):
                for row in sequence1:
                    bit_err = choice(sequence3)
                    num_err -= bit_err

                    sequence2 =  [i for i in range(16)]
                    for _ in range(bit_err):
                        column =choice(sequence2)
                        sequence2.remove(column)
                        brams[bram_no][row][column] = 0
                    if(num_err <= 0):
                        break

if(args['model'] == '2'):

    f = open(path_column_percentage,"r")
    arr = [0 for i in range(1024)]
    for i,x in enumerate(f):
        arr[i] = float(x)

    sequence5 = [0 for i in range(num_of_faulty_brams)] + [1 for i in range(fault)]
    sequence1 = [i for i in range(1024)]
    sequence2 = [i for i in range(16)]

    min=1
    for w in arr:
        if(w > 0):
            if(w < min):
                min = w
    x = 1/min
    sequence3 = [0 for i in range(0)]
    for i,a in enumerate(arr):
        sequence3 += [i for t in range(int(x*a))]

    random.shuffle(sequence5)
    random.shuffle(sequence3)

    while num_err > 0:
        for bram_no,is_faulty in enumerate(sequence5):
            if( is_faulty == 0):
                for column in sequence2:
                    bit_err = choice(sequence3)
                    num_err -= bit_err
                    sequence1 = [i for i in range(1024)]
                    for _ in range(bit_err):
                        row = choice(sequence1)
                        sequence1.remove(row)
                        brams[bram_no][row][column] = 0
                    if(num_err <= 0):
                        break

if(args['model'] == '3'):

    sequence1 = [i for i in range(1024)]
    sequence2 = [i for i in range(8)]
    sequence5 = [0 for i in range(num_of_faulty_brams)] + [1 for i in range(fault)]

    ff = open(path_row_distance,"r")
    ar = [0 for i in range(16)]
    for i,x in enumerate(ff):
        ar[i] = int(x)
    min=1
    for w in ar:
        if(w > 0):
            if(w < min):
                min = w
    x = 1/min
    sequence6 = [0 for i in range(0)]
    for i,a in enumerate(ar):
            sequence6 += [i for t in range(int(x*a))]

    ff = open(path_column_distance,"r")
    ar = [0 for i in range(1024)]
    for i,x in enumerate(ff):
        ar[i] = int(x)
    min=1
    for w in ar:
        if(w > 0):
            if(w < min):
                min = w
    x = 1/min
    sequence7 = [0 for i in range(0)]
    for i,a in enumerate(ar):
            sequence7 += [i for t in range(int(x*a))]

    f = open(path_column_percentage,"r")
    arr = [0 for i in range(1024)]
    for i,x in enumerate(f):
        arr[i] = float(x)
    min=1
    for w in arr:
        if(w > 0):
            if(w < min):
                min = w
    x = 1/min
    sequence4 = [0 for i in range(0)]
    for i,a in enumerate(arr):
            sequence4 += [i for t in range(int(x*a))]

    f = open(path_row_percentage,"r")
    arr = [0 for i in range(16)]
    for i,x in enumerate(f):
        arr[i] = float(x)
    min=1
    for w in arr:
        if(w > 0):
            if(w < min):
                min = w
    x = 1/min
    sequence3 = [0 for i in range(0)]
    for i,a in enumerate(arr):
            sequence3 += [i for t in range(int(x*a))]

    random.shuffle(sequence5)
    random.shuffle(sequence3)
    random.shuffle(sequence4)


    sequence1 = [i for i in range(1024)]
    sequence2 = [i for i in range(8)]
    num_err=num_err/2
    while num_err > 0:
        for bram_no,is_faulty in enumerate(sequence5):
                if( is_faulty == 0):
                    for column in sequence2:
                        bit_err = choice(sequence4)
                        num_err -= bit_err
                        sequence1 = [i for i in range(1024)]
                        for _ in range(bit_err):
                            row = choice(sequence1)
                            sequence1.remove(row)
                            brams[bram_no][row][column] = 0
                            brams[bram_no][row][((column+choice(sequence6))%16)] = 0
                    if(num_err <= 0):
                        break
path_result = pwd + "result"
result = open(path_result,"w")
for k,a in enumerate(brams):
    for i,b in enumerate(a):
        for j,c in enumerate(b):
            if(c == 0):
                bit_location = j + i*16 + k*1024
                str = "{}\n".format(bit_location)
                result.write(str)

result.close()
