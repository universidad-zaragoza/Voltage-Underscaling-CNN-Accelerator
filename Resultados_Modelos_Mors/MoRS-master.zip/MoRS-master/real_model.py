import argparse
import array as arr
import numpy as np
import per_bram
from random import seed
from random import choice
import random
seed(random)
parser = argparse.ArgumentParser()
parser.add_argument("-b","--board",required=True,
                    help='Board Selection. available boards:KC705B or VC707')
parser.add_argument("-v","--voltage-level",required=True,
                    help='Voltage Level, for KC705B interval is 0.59-0.53, for VC707 is 0.60-0.54')

args = vars(parser.parse_args())

if(args['board'] == 'KC705B'):
    number_of_bram = 890
elif(args['board'] == 'VC707'):
    number_of_bram = 2060

filename = args['board'] + "-" + args['voltage_level'] + ".bin"
pwd = "/home/ismail/FPGA-BRAMs-Undervoltig-Study/fault_characterization/"
path = pwd + args['board'] + "/RawData/" + filename
f = open(path,"r")

brams = per_bram.initiliaze_per_bram_matrix(f,number_of_bram)

path_result = pwd + "result"
result = open(path_result,"w")
for k,a in enumerate(brams):
    for i,b in enumerate(a):
        for j,c in enumerate(b):
            if(c == 0):
                bit_location = j + i*16 + k*1024
                str = "{}\n".format(bit_location)
                result.write(str)

result.close()
