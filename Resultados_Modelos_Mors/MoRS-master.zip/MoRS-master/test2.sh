#!/bin/bash
echo "Starting.."
board="KC705B"
txt="$board.txt"
rm $txt
for i in {59..53..1}
do
     python test.py --board=$board --voltage-level=0.$i;
     #python row_based.py --board=$board --voltage-level=0.$i --model=3 --num_test=1 ;
     echo "$board $i Done"

done
board="VC707"
txt="$board.txt"
rm $txt
for i in {60..54..1}
do
     python test.py --board=$board --voltage-level=0.$i;
     #python row_based.py --board=$board --voltage-level=0.$i --model=3 --num_test=1;
     echo "$board $i Done"
done

echo "Finished"
