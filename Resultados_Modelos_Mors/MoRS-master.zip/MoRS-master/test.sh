#!/bin/bash
echo "Starting.."
board="KC705B"
txt="$board.txt"
rm $txt
for i in {59..53..1}
do
     python bram_stats.py --board=$board --voltage-level=0.$i >> $txt;
     echo "$board $i Done"

done
board="VC707"
txt="$board.txt"
rm $txt
for i in {60..54..1}
do
     python bram_stats.py --board=$board --voltage-level=0.$i >> $txt;

done

echo "Finished"
